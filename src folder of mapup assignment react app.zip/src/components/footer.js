import './footer.css';


function Footer(){
    return (
        <div class="footer">
           foooter 
        </div>
    )
}

export default Footer;